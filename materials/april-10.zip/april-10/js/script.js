$(document).ready(function(){

	console.log("hello Spring!")

	// set

	// TweenMax.set($("#ourdiv"), {	x: "100px", 
	// 								backgroundColor: "rgb(0,0,255)"
	// 							})

	// to

	// TweenMax.to($("#ourdiv"), 2, {	x: "100px", 
	// 								backgroundColor: "rgb(0,0,255)"
	// 							})
	// TweenMax.to($("#ourotherdiv"), 2, {	x: "100px", 
	// 								backgroundColor: "rgb(0,0,255)",
	// 								delay: 1
	// 							})



	var animateAll = function(){
		$("div").each(function(){

			var thisDiv = $(this);
			var thisIndex = thisDiv.index()
			console.log(thisIndex)
			
			TweenMax.to(thisDiv, 1, {	x: "100px", 
										backgroundColor: "rgb(0,0,255)",
										delay : thisIndex/2,
										ease: Power4.easeIn
									})
		})
	}

	var animateTimeLine = function(){

		var ourTimeline = new TimelineMax({repeat: 0})

		ourTimeline.add(TweenMax.to($("div"), 1, {y: "100px"}))
		ourTimeline.add(TweenMax.to($("div"), 1.25, {x: "150px", backgroundColor: "rgb(0,0,0)"}))
		ourTimeline.add(TweenMax.to($("div"), 0.5, {x: "100px"}))
		ourTimeline.add(TweenMax.to($("div"), 1.25, {x: "150px", backgroundColor: "rgb(0,255,0)"}))
		
	}

	$("div").click(function(){
		// animateAll()
		// TweenMax.to($("div"), 1, {y: "100px"})
		// TweenMax.to($("div"), 1.25, {delay: 1, x: "150px", backgroundColor: "rgb(0,0,0)"})
		// TweenMax.to($("div"), 0.5, { delay: 1.5, x: "100px"})
	

		animateTimeLine()




	})


	// fromTo
	// TweenMax.fromTo($("#ourotherdiv"), 2, 
	// 							{
	// 								x : "50px",
	// 								backgroundColor : "rgb(0,255,0)"
	// 							},
	// 							{	x: "100px", 
	// 								backgroundColor: "rgb(0,0,255)",
	// 								delay: 1
	// 							})


	// from

	// TweenMax.from($("#ourdiv"), 4, {y: "50px", 
	// 								backgroundColor: "green",
	// 								ease: Elastic.easeIn.config(1, 0.3),
	// 								onComplete : function(){
	// 									animateAll()
	// 									//window.location = "https://google.com"

	// 								}
	// 							})












})