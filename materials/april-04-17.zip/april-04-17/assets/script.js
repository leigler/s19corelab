console.log("hello!")

var myFunction = function(event){

	// console log: a method of identifying whether variables exist and how they are defined for systematic debugging
	console.log("event: ", event)
	// console.log is best used with a titling mechanism
	// this allows you to clearly identify where a logged value is coming from

	for (var i = 0; i < 10; i++) {
		console.log("index: ", i, event) // example of using console.log to identify how far into a for loop you are 

	}
	console.log(asdf) // an error is thrown because "asdf" is not defined. 
	// in our browser's inspect element > console window, we are given the line where this error is thrown


}

myFunction("event?")